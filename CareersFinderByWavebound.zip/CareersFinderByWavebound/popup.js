// document.addEventListener('DOMContentLoaded', (event) => {
//     document.body.addEventListener('click', () => {
//         console.log('Sending message to content script');
//         chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
//             chrome.tabs.sendMessage(tabs[0].id, {type: 'getCareersUrl'}, (response) => {
//                 console.log('Received response:', response);
//                 if (response && response.url) {
//                     chrome.tabs.update(tabs[0].id, { url: response.url });
//                 } else {
//                     alert('Sorry! I am unable to find a careers page on this site.');
//                 }
//             });
//         });
//     });
// });
